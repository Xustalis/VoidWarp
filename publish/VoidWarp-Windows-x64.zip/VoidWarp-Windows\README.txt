VoidWarp Windows Client - Self-Contained Edition
=================================================

Usage:
  1. Run VoidWarp.Windows.exe directly
  2. Or run install.bat to create shortcuts
  3. If Android cannot find Windows: Run setup_firewall.bat as Administrator

Features:
  - No .NET Runtime installation required
  - No VC++ Redistributable required
  - Ready to use out of the box

System Requirements:
  - Windows 10/11 x64

